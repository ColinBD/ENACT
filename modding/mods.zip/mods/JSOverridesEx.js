//alert("we're in H5P external mode!");

/*
// Add to the top of the javascript file.
var __oldJQuery = jQuery;
jQuery = H5P.jQuery;
 
//
// jQuery extension code goes here. Remember to keep license information
// and other file intro comments.
//
 
// Add to the end of the javascript file.

if (jQuery) {  
    // jQuery is loaded  
    alert("Yeah!");
  } else {
    // jQuery is not loaded
    alert("Doesn't Work");
  }

jQuery = __oldJQuery;
*/